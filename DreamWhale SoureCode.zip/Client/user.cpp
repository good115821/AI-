#include "user.h"

User::User()
{

}
